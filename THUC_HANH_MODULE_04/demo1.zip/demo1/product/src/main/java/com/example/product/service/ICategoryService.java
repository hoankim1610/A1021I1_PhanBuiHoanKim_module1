package com.example.product.service;

import com.example.product.model.Category;

import java.util.List;

public interface ICategoryService {
    List<Category> findAll();

}
