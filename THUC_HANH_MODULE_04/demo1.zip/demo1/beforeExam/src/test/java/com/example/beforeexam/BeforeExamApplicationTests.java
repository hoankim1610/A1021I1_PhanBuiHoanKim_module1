package com.example.beforeexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeforeExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
