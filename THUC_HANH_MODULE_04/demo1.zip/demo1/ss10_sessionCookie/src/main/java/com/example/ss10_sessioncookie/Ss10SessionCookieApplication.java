package com.example.ss10_sessioncookie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ss10SessionCookieApplication {

    public static void main(String[] args) {
        SpringApplication.run(Ss10SessionCookieApplication.class, args);
    }

}
