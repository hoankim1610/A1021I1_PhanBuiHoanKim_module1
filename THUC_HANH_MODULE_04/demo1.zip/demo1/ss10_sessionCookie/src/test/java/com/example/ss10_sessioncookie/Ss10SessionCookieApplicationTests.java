package com.example.ss10_sessioncookie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ss10SessionCookieApplicationTests {

    @Test
    void contextLoads() {
    }

}
