package com.example.beforeexam.service;

import com.example.beforeexam.model.Instructor;

import java.util.List;

public interface IInstructorService {
    List<Instructor> findAll();
}
