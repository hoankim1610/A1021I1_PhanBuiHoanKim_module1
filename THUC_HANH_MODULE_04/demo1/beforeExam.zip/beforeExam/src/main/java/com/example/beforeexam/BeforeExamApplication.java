package com.example.beforeexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeforeExamApplication {

    public static void main(String[] args) {
        SpringApplication.run(BeforeExamApplication.class, args);
    }

}
